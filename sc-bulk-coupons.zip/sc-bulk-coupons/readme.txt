=== SureCart Bulk Coupons Generator ===
Contributors: reallyusefulplugins
Donate link: https://reallyusefulplugins.com/donate
Tags: Bulk Coupons, Sure Cart, Coupons
Requires at least: 6.5
Tested up to: 6.9
Stable tag: 1.3.0
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

SureCart Bulk Coupon Generator - Generate Coupons in Bulk for SureCart


== Description ==
SureCart Bulk Coupon Generator - Generate Coupons in Bulk for SureCart

== Installation ==

1. Upload the `sc- bulk-coupons` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Its now ready to use

== Frequently Asked Questions ==

= How do I add use the plugin? =
Navigate to tools and surecart bulk coupons and fill out the required fields 







== Changelog ==
= 1.3 December 2025 =
New: Ability to Add Coupons to an Existing Campaign

= 1.2 October 2025 =
New: Product Selector updates
New: CSV output, Coupons Only or Both and original full

= 1.1.1 September 2025 =
Fixed: Minimum Order Subtotal

= 1.1 September 2025 =
New: Select 2 - Multiselect
New: Saves generation details
New: Reset Button

= 1.0 September 2025 =
New: New Queries API for Products
New: Supports Multi-Select

= 0.9 August 2025 =
New: Initial Release